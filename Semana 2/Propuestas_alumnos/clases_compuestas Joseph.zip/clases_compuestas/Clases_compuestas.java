/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.company.clases_compuestas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author joubr
 */
public class Clases_compuestas {
    /*
    Aqui cibtiene todo el codigo pincipal. lOS MENU DE DOCENTE Y ADMINISTRADOR.
    por default, ya viene incluido un docente. Su nombre es "default", y ;a contra es "12345678".
    */
    public static ArrayList<docente> docentes = new ArrayList();
    public static docente defaultDocente = new docente("default", "12345678");
    
    public static void docenteVerificacion(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese su nombre: ");
        String nombre = reader.nextLine();
        for (int i = 0; i < docentes.size(); i++) {
            if(docentes.get(i).getNombre().equalsIgnoreCase(nombre)){
                System.out.println("Ingrese su contra: ");
                String contra = reader.nextLine();
                if(docentes.get(i).getContra().equals(contra)){
                    docencteMenu(i);
                }else{
                    System.out.println("contra incorecto");
                }
            }else{
                System.out.println("Usuario no encontrado");
            }
        }
    }
    
    public static void docencteMenu(int i){
        Scanner readerInt = new Scanner(System.in);
        boolean exit = false;
        while(!exit){
            System.out.println("""
                               ----Docente----
                               1. crear secion
                               2. agregar estudiante
                               3. eliminar estudiante
                               4. marcar asistencia
                               5. ver lista de asistencia
                               6. ver seciones
                               7. editar alumno
                               8. salir
                               """);
            int input = readerInt.nextInt();
            switch(input){
                case 1-> docentes.get(i).crearSecion();
                case 2-> docentes.get(i).agregarEstudiante();
                case 4-> docentes.get(i).marcarAsistencia();
                case 3-> docentes.get(i).eliminarEstudiante();
                case 5-> docentes.get(i).mostrarAsistencia();
                case 6-> docentes.get(i).verSeciones();
                case 7-> docentes.get(i).editarAlumno();
                case 8-> exit = true;
                default ->{
                    System.out.println("""
                                       Input no valido
                                       """);
                }
            }
        }
    }
    
    public static void verDocentes(){
        for (int i = 0; i < docentes.size(); i++) {
            System.out.println("Docente #"+i+":   "+docentes.get(i).getNombre());
        }
    }
    
    public static void agregarDocente(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese su Nombre");
        String nombre = reader.nextLine();
        System.out.println("Ingrese contra");
        String contra = reader.nextLine();
        docentes.add(new docente(nombre, contra));
        System.out.println("""
                           se agrego el docente
                           """);
    }
    
    public static void administradorMenu(){
        Scanner readerInt = new Scanner(System.in);
        boolean exit = false;
        while(!exit){
            System.out.println("""
                               ----Admin----
                               1. agregar docente
                               2. ver docentes
                               3. salir
                               """);
            int input = readerInt.nextInt();
            switch(input){
                case 1-> agregarDocente();
                case 2-> verDocentes();
                case 3-> exit = true;
                default ->{
                    System.out.println("""
                                       input no valido
                                       """);
                }
            }
        }
        
    }

    public static void main(String[] args) {
        docentes.add(defaultDocente);
        Scanner readerInt = new Scanner(System.in);
        boolean exit = false;
        while(!exit){
            System.out.println("""
                               --------
                               1. administrador
                               2. docente
                               3. salir
                               """);
            int input = readerInt.nextInt();
            switch(input){
                case 1-> administradorMenu();
                case 2-> docenteVerificacion();
                case 3-> exit = true;
                default ->{
                    System.out.println("""
                                       Input no valido
                                       """);
                }
            }
        }
    }
}
