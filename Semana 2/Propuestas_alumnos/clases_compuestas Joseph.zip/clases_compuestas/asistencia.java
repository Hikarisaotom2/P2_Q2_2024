/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.clases_compuestas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author joubr
 */
public class asistencia {
    //propiedades
    private final String fecha;
    private final ArrayList<alumno> alumnos;
    private final ArrayList<String> asistencia;
    
    //contructor
    public asistencia(String fecha, ArrayList<alumno> alumnos) {
        this.asistencia = new ArrayList();
        this.fecha = fecha;
        this.alumnos = alumnos;
    }

    //getters
    public ArrayList<String> getAsistencia() {
        return asistencia;
    }

    public String getFecha() {
        return fecha;
    }
    
    
    //cosas
    public void marcarAsistencia(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < this.alumnos.size(); i++) {
            printAlumno(i);
            System.out.println("""
                               Marcar asistencia
                               Y o N
                               """);
            String marcar = reader.nextLine();
            if(marcar.equalsIgnoreCase("Y")){
                asistencia.add(i, "Y");
            }else{
                this.asistencia.add(i, "N");
            }
        }
        System.out.println("Se marco la asistencia");
    }
    
    public void verAsistencia(){
        if(this.asistencia.size()==0){
            System.out.println("No se encontro asistencia");
        }else{
            for (int i = 0; i < alumnos.size(); i++) {
                printAlumno(i);
                if(i<this.asistencia.size()){
                    printAsistencia(i);
                }else{
                    System.out.println("Asistencia: N/A");
                }
            }
        }
    }
    
    public void printAsistencia(int i){
        System.out.println("Asistencia: "+this.asistencia.get(i));
    }
    
    public void printAlumno(int i){
        System.out.println("Nombre:     "+this.alumnos.get(i).getNombre());
        System.out.println("ID:         "+this.alumnos.get(i).getNumCuenta());
        System.out.println("Carera:     "+this.alumnos.get(i).getCarera());
        System.out.println("------------------------------");
    }

    @Override
    public String toString() {
        return "fecha=" + fecha;
    }
}
