/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.clases_compuestas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author joubr
 */
public class docente {
    /*
    Cada docente tiene una secion de preuba, con tres estudiantes ingresado.
    Esto es para probar el sistema de asistencia
    */
    private final String nombre;
    private final String contra;
    private final secion prueba = new secion("prueba", "06:00", "UNITECT TGU");
    private final ArrayList<secion>seciones = new ArrayList();

    public docente(String nombre, String contra) {
        this.nombre = nombre;
        this.contra = contra;
        this.seciones.add(prueba);
        this.seciones.get(0).alumnosDefault();
    }

    public String getNombre() {
        return nombre;
    }

    public String getContra() {
        return contra;
    }
    
    public void crearSecion(){
        Scanner reader = new Scanner(System.in);
        System.out.println("Ingrese Nombre");
        String nombreSecion = reader.nextLine();
        System.out.println("Ingrese Hora");
        String horaSecion = reader.nextLine();
        System.out.println("Ingrese Campus");
        String campusSecion = reader.nextLine();
        seciones.add(new secion(nombreSecion, horaSecion, campusSecion));
    }
    
    public void verSeciones(){
        for (int i = 0; i < this.seciones.size(); i++) {
            System.out.println("Secion "+i+": "+this.seciones.get(i).toString());
        }
    }
    
    public void printSeciones(int i){
        System.out.println(i+" "+seciones.get(i).toString());
    }
    
    public void agregarEstudiante(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < seciones.size(); i++) {
            printSeciones(i);
        }
        System.out.println("------------------------------");
        System.out.println("selecione la secion");
        int input = reader.nextInt();
        if(input>=seciones.size() || input<0){
            System.out.println("Input no valido");
        }else{
            seciones.get(input).agregarAlumno();
        }
    }
    
    public void editarAlumno(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < seciones.size(); i++) {
            printSeciones(i);
        }
        System.out.println("------------------------------");
        System.out.println("selecione la secion");
        int input = reader.nextInt();
        if (input >= seciones.size() || input < 0) {
            System.out.println("Input no valido");
        } else {
            this.seciones.get(input).editarAlumno();
        }
    }
    
    public void eliminarEstudiante(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < seciones.size(); i++) {
            printSeciones(i);
        }
        System.out.println("------------------------------");
        System.out.println("selecione la secion");
        int input = reader.nextInt();
        if (input >= seciones.size() || input < 0) {
            System.out.println("Input no valido");
        } else {
            seciones.get(input).eliminarAlumno();
        }
    }
    
    public void marcarAsistencia(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < seciones.size(); i++) {
            printSeciones(i);
        }
        System.out.println("------------------------------");
        System.out.println("selecione la secion");
        int input = reader.nextInt();
        if(input>=seciones.size() || input<0){
            System.out.println("Input no valido");
        }else{
            this.seciones.get(input).marcarAsistencia();
        }
    }
    
    public void mostrarAsistencia(){
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < seciones.size(); i++) {
            printSeciones(i);
        }
        System.out.println("------------------------------");
        System.out.println("selecione la secion");
        int input = reader.nextInt();
        if(input>=seciones.size() || input<0){
            System.out.println("Input no valido");
        }else{
            seciones.get(input).verAsistencia();
        }
    }
}
