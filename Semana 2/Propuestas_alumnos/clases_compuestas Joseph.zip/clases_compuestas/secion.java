/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.clases_compuestas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author joubr
 */
public class secion {
    private String nombre;
    private String hora;
    private String campus;
    private ArrayList<alumno> alumnos;
    private ArrayList<asistencia> asistencia;

    //constructor
    public secion(String nombre, String hora, String campus) {
        this.asistencia = new ArrayList();
        this.alumnos = new ArrayList();
        this.nombre = nombre;
        this.hora = hora;
        this.campus = campus;
    }
    
    //clases
    public void agregarAlumno(){
        Scanner reader = new Scanner(System.in);
        Scanner readerInt = new Scanner(System.in);
        System.out.println("Ingresar nombre: ");
        String alumno = reader.nextLine();
        System.out.println("Ingrese numero de cuenta: ");
        int numCuenta = readerInt.nextInt();
        System.out.println("Ingrese la carrera");
        String carrera = reader.nextLine();
        alumnos.add(new alumno(alumno, numCuenta, carrera));
        System.out.println("""
                           se agrego el alumno
                           """);
    }
    
    public void alumnosDefault(){
        alumno alumnoOne = new alumno("alumno #1", 123456, "Inge");
        alumno alumnoTwo = new alumno("alumno #2", 654321, "medicina");
        alumno alumnoThree = new alumno("alumno #3", 135780, "cocina");
        this.alumnos.add(alumnoOne);
        this.alumnos.add(alumnoTwo);
        this.alumnos.add(alumnoThree);
    }
    
    public void editarAlumno(){
        Scanner readerInt = new Scanner(System.in);
        Scanner reader = new Scanner(System.in);
        for (int i = 0; i < this.alumnos.size(); i++) {
            System.out.println("Opcion: " + i);
            printAlumno(i);
        }
        System.out.println("Selecione el alumno que editar: ");
        int input = readerInt.nextInt();
        if (input >= alumnos.size() || input < 0) {
            System.out.println("Input no valido");
        }else{
            printAlumno(input);
            System.out.println("""
                               1. nombre
                               2. carera
                               """);
            int inputChange = readerInt.nextInt();
            switch(inputChange){
                case 1->{
                    System.out.println("ingrese el nombre");
                    String nameNew = reader.nextLine();
                    this.alumnos.get(input).setNombre(nameNew);
                }
                case 2->{
                    System.out.println("ingrese la carera");
                    String careraNew = reader.nextLine();
                    this.alumnos.get(input).setCarera(careraNew);
                }
                default ->{
                    System.out.println("input no valido");
                }
            }
            System.out.println("Se cumplio los cambios");
        }
}
    
    public void eliminarAlumno(){
        Scanner readerInt = new Scanner(System.in);
        for (int i = 0; i < this.alumnos.size(); i++) {
            System.out.println("Opcion: "+i);
            printAlumno(i);
        }
        System.out.println("Selecione el alumno que eliminar: ");
        int input = readerInt.nextInt();
        if(input>=alumnos.size() || input<0){
            System.out.println("Input no valido");
        }else{
            this.alumnos.remove(input);
            System.out.println("""
                               Se elimino el alumno
                               """);
        }
    }
    
    public void marcarAsistencia(){
        Scanner reader = new Scanner(System.in);
        if(this.alumnos.size()==0){
            System.out.println("No se encontro estudiantes");
        }else{
            System.out.println("Ingrese la fecha: dd/mm/aa");
            String date = reader.nextLine();
            this.asistencia.add(new asistencia(date, this.alumnos));
            this.asistencia.get(this.asistencia.size()-1).marcarAsistencia();
        }
    }
    
    public void verAsistencia(){
        if(this.asistencia.isEmpty()){
            System.out.println("No hay lista de asistencia que presentar");
        }else{
            Scanner reader = new Scanner(System.in);
            for (int i = 0; i < asistencia.size(); i++) {
                System.out.println(i+" "+this.asistencia.get(i).toString());
            }
            System.out.println("------------------------------");
            System.out.println("escoge la fecha");
            int input = reader.nextInt();
            asistencia.get(input).verAsistencia();
        }
    }
    
    public void printAlumno(int i){
        System.out.println("Nombre:     "+this.alumnos.get(i).getNombre());
        System.out.println("ID:         "+this.alumnos.get(i).getNumCuenta());
        System.out.println("Carera:     "+this.alumnos.get(i).getCarera());
        System.out.println("------------------------------");
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", hora=" + hora + ", campus=" + campus;
    }
    
    
}
