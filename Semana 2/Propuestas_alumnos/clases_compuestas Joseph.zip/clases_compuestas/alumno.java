/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.company.clases_compuestas;

/**
 *
 * @author joubr
 */
public class alumno {
    private String nombre;
    private  int numCuenta;
    private String carera;
    
    //constructor
    public alumno(String nombre, int numCuenta, String carera) {
        this.nombre = nombre;
        this.numCuenta = numCuenta;
        this.carera = carera;
    }
    
    //getters
    public String getNombre() {
        return nombre;
    }

    public int getNumCuenta() {
        return numCuenta;
    }

    public String getCarera() {
        return carera;
    }
    
    //setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setNumCuenta(int numCuenta) {
        this.numCuenta = numCuenta;
    }

    public void setCarera(String carera) {
        this.carera = carera;
    }
    
    public void lol(){
        
    }
}
